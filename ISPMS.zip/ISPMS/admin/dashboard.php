<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ispmsaid']==0)) {
  header('location:logout.php');
  } else{



  ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/litepicker/dist/css/litepicker.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
        <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.28.0/feather.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="nav-fixed">
        <?php include_once('includes/header.php');?>
        <div id="layoutSidenav">
            <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container-xl px-4">
                            <div class="page-header-content pt-4">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-auto mt-4">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="align-justify"></i></div>
                                            Dashboard
                                        </h1>
                                        <div class="page-header-subtitle">Welcome to Admin Panel</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container-xl px-4 mt-n10">
                     
                        <!-- Example Colored Cards for Dashboard Demo-->
                        <div class="row">
                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-warning text-white h-100">
                                    <div class="card-body">
                                        <?php 
                                            $sql5 ="SELECT * from  tblbookdthplan where Status is null ";
                                            $query5 = $dbh -> prepare($sql5);
                                            $query5->execute();
                                            $results5=$query5->fetchAll(PDO::FETCH_OBJ);
                                            $totnewreq1=$query5->rowCount();
                                        ?>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="me-3">
                                                    <div class="text-white-75 small">New DTH Request</div>
                                                    <div class="text-lg fw-bold"><?php echo htmlentities($totnewreq1);?></div>
                                                </div>
                                                <i class="feather-xl text-white-50" data-feather="users"></i>
                                            </div>
                                    </div>
                                        <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="new-dthrequest.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                </div>
                            </div>
                        </div>

                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-primary text-white h-100">
                                    <div class="card-body">
                                        <?php 
                        $sql6 ="SELECT * from  tblbookdthplan where Status='Assign'";
$query6 = $dbh -> prepare($sql6);
$query6->execute();
$results6=$query6->fetchAll(PDO::FETCH_OBJ);
$totassignreq1=$query6->rowCount();
?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="me-3">
                                                <div class="text-white-75 small">Assigned DTH  Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totassignreq1);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="inbox"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="assign-dthrequest.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-success text-white h-100">
                                    <div class="card-body">
                                        <?php 
                        $sql8 ="SELECT * from  tblbookdthplan where Status='Completed'";
$query8 = $dbh -> prepare($sql8);
$query8->execute();
$results8=$query8->fetchAll(PDO::FETCH_OBJ);
$totcomreq1=$query8->rowCount();
?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="me-3">
                                                <div class="text-white-75 small">Completed DTH Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totcomreq1);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="user-check"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="completed-dthrequest.php">View Requests</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-danger text-white h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center"><?php 
                        $sql7 ="SELECT * from  tblbookdthplan where Status='Rejected'";
$query7 = $dbh -> prepare($sql7);
$query7->execute();
$results7=$query7->fetchAll(PDO::FETCH_OBJ);
$totrejreq1=$query7->rowCount();
?>
                                            <div class="me-3">
                                                <div class="text-white-75 small">Rejected DTH Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totrejreq1);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="user-x"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="rejected-dthrequest.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-warning text-white h-100">
                                    <div class="card-body">
                                        <?php 
                        $sql1 ="SELECT * from  tblbookbplan where Status is null ";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$totnewreq=$query1->rowCount();
?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="me-3">
                                                <div class="text-white-75 small">New Broadband Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totnewreq);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="users"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="new-request.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-primary text-white h-100">
                                    <div class="card-body">
                                        <?php 
                        $sql2 ="SELECT * from  tblbookbplan where Status='Assign'";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$totassignreq=$query2->rowCount();
?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="me-3">
                                                <div class="text-white-75 small">Assign Broadband Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totassignreq);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="inbox"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="assign-request.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-success text-white h-100">
                                    <div class="card-body">
                                        <?php 
                        $sql3 ="SELECT * from  tblbookdthplan where Status='Completed'";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$results3=$query3->fetchAll(PDO::FETCH_OBJ);
$totcomreq=$query3->rowCount();
?>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="me-3">
                                                <div class="text-white-75 small">Completed Broadband Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totcomreq);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="user-check"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="completed-request.php">View Requests</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-xl-3 mb-4">
                                <div class="card bg-danger text-white h-100">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center"><?php 
                        $sql3 ="SELECT * from  tblbookbplan where Status='Rejected'";
$query3 = $dbh -> prepare($sql3);
$query3->execute();
$results3=$query3->fetchAll(PDO::FETCH_OBJ);
$totrejreq=$query3->rowCount();
?>
                                            <div class="me-3">
                                                <div class="text-white-75 small">Rejected Broadband Request</div>
                                                <div class="text-lg fw-bold"><?php echo htmlentities($totrejreq);?></div>
                                            </div>
                                            <i class="feather-xl text-white-50" data-feather="user-x"></i>
                                        </div>
                                    </div>
                                    <div class="card-footer d-flex align-items-center justify-content-between small">
                                        <a class="text-white stretched-link" href="rejected-request.php">View Details</a>
                                        <div class="text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include_once('includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables/datatables-simple-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/litepicker/dist/bundle.js" crossorigin="anonymous"></script>
        <script src="js/litepicker.js"></script>
    </body>
</html>
<?php } ?>